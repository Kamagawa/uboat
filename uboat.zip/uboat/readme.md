# Play to Jira
Play to Jira is a browser extension that enables user to add jira issue to their designated address

## Feature
 * One click to add Google Play review to Jira issue
 * Customize and add specific info to Jira issues
 * Set your own Jira directory
 * Will hopefully work with Github

## Installation
### Google Chrome(Development)
 1. git clone https://github.com/kamagawa/uboat.git
 2. Go to Chrome://extension, and click on load unpack extension
 3. Load the folder the contains this repo
 4. Rrefresh the page

### Google Chrome(Production)
 1. Not out yet
 
### FireFox
 1. Go to google, search Google Chrome download
 2. install Google Chrome, and follow the Google Chrome Installation instruction

## Contributors
 1. Fork this repository
 2. Create a branch and make your changes
 3. Submit a pull request
 4. I will definitely review your pull request for sure
 5. ???
 6. Profit

 